# 技术方案设计文档

## 1. 项目概述

### 1.1 项目目标
构建一个多链 ERC20 代币事件追踪和积分计算系统，实现：
- 追踪代币转账、铸造、销毁事件
- 重建用户余额状态
- 基于持有时间和余额计算积分
- 支持多链部署（Sepolia、Base Sepolia）
- 支持积分回溯计算

### 1.2 核心需求
1. ✅ 部署带 mint 和 burn 功能的 ERC20 合约
2. ✅ Go 后端服务追踪合约事件，重建用户余额
3. ✅ 以太坊 6 个区块延迟确认机制
4. ✅ 积分计算功能（每小时定时任务）
5. ✅ 记录用户所有余额变化
6. ✅ 维护用户总余额表、总积分表、余额变动记录表
7. ✅ 支持多链逻辑（Sepolia、Base Sepolia）
8. ✅ 支持积分回溯计算（处理服务中断场景）

### 1.3 技术栈
- **智能合约**: Solidity 0.8.20 + OpenZeppelin + Hardhat
- **后端服务**: Go 1.21+ + Gin + sqlx + Cobra + Viper
- **数据库**: PostgreSQL 17
- **区块链交互**: go-ethereum (geth)
- **定时任务**: robfig/cron
- **配置管理**: YAML (dev/prod环境分离)
- **日志**: logrus

---

## 2. 系统架构设计

### 2.1 整体架构图

```
┌────────────────────────────────────────────────────────────────┐
│                     区块链网络层                                  │
│  ┌─────────────────┐         ┌─────────────────┐               │
│  │  Sepolia        │         │  Base Sepolia   │               │
│  │  Testnet        │         │  Testnet        │               │
│  │  ERC20 Contract │         │  ERC20 Contract │               │
│  └────────┬────────┘         └────────┬────────┘               │
│           │                           │                         │
└───────────┼───────────────────────────┼─────────────────────────┘
            │                           │
            │  WebSocket/HTTP RPC       │
            │                           │
┌───────────▼───────────────────────────▼─────────────────────────┐
│                   Go 后端服务 (Cobra CLI)                        │
│                                                                  │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │             配置管理层 (Viper + YAML)                      │  │
│  │  - config/dev.yaml  - config/prod.yaml                   │  │
│  └──────────────────────────────────────────────────────────┘  │
│                                                                  │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │               命令行接口 (Cobra)                           │  │
│  │  - start      启动所有服务                                 │  │
│  │  - listener   仅启动事件监听                               │  │
│  │  - calculator 仅启动积分计算                               │  │
│  │  - api        仅启动API服务                                │  │
│  │  - migrate    数据库迁移                                   │  │
│  └────────────┬─────────────────────────────────┬─────────────┘  │
│               │                                 │                │
│  ┌────────────▼──────────────┐    ┌────────────▼──────────────┐│
│  │   事件监听服务 (Listener)  │    │   HTTP API 服务 (Gin)     ││
│  │  - 多链并发监听             │    │  - 查询余额/积分           ││
│  │  - 事件解析和处理           │    │  - 查询变动历史            ││
│  │  - 6区块延迟确认           │    │  - 健康检查                ││
│  │  - 断点续传                │    │  - 系统状态                ││
│  └────────────┬──────────────┘    └────────────┬──────────────┘│
│               │                                 │                │
│  ┌────────────▼─────────────────────────────────▼──────────────┐│
│  │                业务逻辑层 (Service)                          ││
│  │  ┌──────────────────┐  ┌──────────────────┐                ││
│  │  │  Balance Service │  │  Points Service  │                ││
│  │  │  - 余额重建       │  │  - 积分计算       │                ││
│  │  │  - 余额查询       │  │  - 积分回溯       │                ││
│  │  └──────────────────┘  └──────────────────┘                ││
│  └──────────────────────────────┬────────────────────────────┘ │
│                                  │                              │
│  ┌──────────────────────────────▼────────────────────────────┐ │
│  │              数据访问层 (Repository + sqlx)                 │ │
│  │  - 余额CRUD  - 积分CRUD  - 变动记录  - 事务管理             │ │
│  └──────────────────────────────┬────────────────────────────┘ │
│                                  │                              │
└──────────────────────────────────┼──────────────────────────────┘
                                   │
┌──────────────────────────────────▼──────────────────────────────┐
│                     PostgreSQL 17 数据库                         │
│                                                                  │
│  ┌──────────────┐ ┌──────────────┐ ┌──────────────┐           │
│  │user_balances │ │ user_points  │ │balance_changes│          │
│  │  用户余额表   │ │  用户积分表   │ │ 余额变动表    │          │
│  └──────────────┘ └──────────────┘ └──────────────┘           │
│                                                                  │
│  ┌──────────────┐ ┌──────────────┐                            │
│  │points_history│ │  sync_state  │                            │
│  │ 积分计算历史  │ │  同步状态表   │                            │
│  └──────────────┘ └──────────────┘                            │
└──────────────────────────────────────────────────────────────────┘
```

### 2.2 分层架构

```
┌─────────────────────────────────────────────────┐
│            展示层 (Presentation)                 │
│  - Cobra CLI Commands                           │
│  - Gin HTTP API Handlers                        │
└────────────────┬────────────────────────────────┘
                 │
┌────────────────▼────────────────────────────────┐
│            业务逻辑层 (Service)                  │
│  - Balance Service (余额管理)                    │
│  - Points Service (积分计算)                     │
│  - Listener Service (事件监听)                   │
└────────────────┬────────────────────────────────┘
                 │
┌────────────────▼────────────────────────────────┐
│          数据访问层 (Repository)                 │
│  - Balance Repository                           │
│  - Points Repository                            │
│  - Sync State Repository                        │
│  - Transaction Manager                          │
└────────────────┬────────────────────────────────┘
                 │
┌────────────────▼────────────────────────────────┐
│            基础设施层 (Infrastructure)           │
│  - Database (PostgreSQL + sqlx)                 │
│  - Blockchain Client (go-ethereum)              │
│  - Config (Viper + YAML)                        │
│  - Logger (logrus)                              │
└─────────────────────────────────────────────────┘
```

---

## 3. 智能合约设计

### 3.1 合约架构

```solidity
// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import "@openzeppelin/contracts/token/ERC20/ERC20.sol";
import "@openzeppelin/contracts/access/Ownable.sol";

contract MyToken is ERC20, Ownable {
    
    // 自定义事件
    event TokenMinted(address indexed to, uint256 amount, uint256 timestamp);
    event TokenBurned(address indexed from, uint256 amount, uint256 timestamp);
    
    constructor() ERC20("MyToken", "MTK") Ownable(msg.sender) {
        // 初始化
    }
    
    // 铸造代币 (仅owner)
    function mint(address to, uint256 amount) public onlyOwner {
        _mint(to, amount);
        emit TokenMinted(to, amount, block.timestamp);
    }
    
    // 销毁代币
    function burn(uint256 amount) public {
        _burn(msg.sender, amount);
        emit TokenBurned(msg.sender, amount, block.timestamp);
    }
    
    // 授权销毁
    function burnFrom(address from, uint256 amount) public {
        _spendAllowance(from, msg.sender, amount);
        _burn(from, amount);
        emit TokenBurned(from, amount, block.timestamp);
    }
}
```

### 3.2 合约事件

| 事件名称 | 参数 | 触发场景 |
|---------|------|---------|
| Transfer | from, to, value | 转账、铸造(from=0)、销毁(to=0) |
| TokenMinted | to, amount, timestamp | 铸造代币 |
| TokenBurned | from, amount, timestamp | 销毁代币 |

### 3.3 部署策略

1. **测试网部署**
   - Sepolia Testnet
   - Base Sepolia Testnet
   
2. **部署脚本** (Hardhat)
   ```javascript
   // scripts/deploy.js
   async function main() {
       const MyToken = await ethers.getContractFactory("MyToken");
       const token = await MyToken.deploy();
       await token.deployed();
       console.log("MyToken deployed to:", token.address);
       
       // 保存部署信息
       const deployment = {
           address: token.address,
           deployer: (await ethers.getSigners())[0].address,
           blockNumber: token.deployTransaction.blockNumber,
           transactionHash: token.deployTransaction.hash,
           timestamp: new Date().toISOString()
       };
       
       fs.writeFileSync(
           `deployments/${network.name}.json`,
           JSON.stringify(deployment, null, 2)
       );
   }
   ```

3. **测试脚本** (构造测试数据)
   ```javascript
   // scripts/interact.js
   async function testOperations() {
       // Mint tokens
       await token.mint(user1.address, ethers.utils.parseEther("100"));
       await token.mint(user2.address, ethers.utils.parseEther("200"));
       
       // Transfer tokens
       await token.connect(user1).transfer(user2.address, ethers.utils.parseEther("30"));
       
       // Burn tokens
       await token.connect(user2).burn(ethers.utils.parseEther("50"));
   }
   ```

---

## 4. 数据库设计

### 4.1 ER图

```
┌─────────────────────────────────────────┐
│           user_balances                 │
│  用户余额表 (当前状态)                    │
├─────────────────────────────────────────┤
│ PK  id                  BIGSERIAL       │
│     chain_name          VARCHAR(50)     │
│     user_address        VARCHAR(42)     │
│     balance             NUMERIC(78,0)   │
│     created_at          TIMESTAMP       │
│     updated_at          TIMESTAMP       │
│ UK  (chain_name, user_address)          │
└─────────────┬───────────────────────────┘
              │
              │ 1:N
              │
┌─────────────▼───────────────────────────┐
│           balance_changes               │
│  余额变动历史表 (事件记录)                │
├─────────────────────────────────────────┤
│ PK  id                  BIGSERIAL       │
│     chain_name          VARCHAR(50)     │
│     user_address        VARCHAR(42)     │
│     change_type         VARCHAR(20)     │  -- transfer_in/out, mint, burn
│     amount              NUMERIC(78,0)   │
│     balance_before      NUMERIC(78,0)   │
│     balance_after       NUMERIC(78,0)   │
│     tx_hash             VARCHAR(66)     │
│     block_number        BIGINT          │
│     block_timestamp     TIMESTAMP       │
│     event_index         INTEGER         │
│     confirmed           BOOLEAN         │  -- 6区块确认
│     created_at          TIMESTAMP       │
│ IDX (chain_name, user_address, created_at) │
│ IDX (chain_name, block_number)          │
│ IDX (confirmed)                         │
└─────────────┬───────────────────────────┘
              │
              │ 用于计算积分
              │
┌─────────────▼───────────────────────────┐
│           user_points                   │
│  用户积分表 (当前状态)                    │
├─────────────────────────────────────────┤
│ PK  id                  BIGSERIAL       │
│     chain_name          VARCHAR(50)     │
│     user_address        VARCHAR(42)     │
│     total_points        NUMERIC(20,10)  │
│     last_calc_at        TIMESTAMP       │
│     created_at          TIMESTAMP       │
│     updated_at          TIMESTAMP       │
│ UK  (chain_name, user_address)          │
└─────────────┬───────────────────────────┘
              │
              │ 1:N
              │
┌─────────────▼───────────────────────────┐
│         points_history                  │
│  积分计算历史表 (审计记录)                │
├─────────────────────────────────────────┤
│ PK  id                  BIGSERIAL       │
│     chain_name          VARCHAR(50)     │
│     user_address        VARCHAR(42)     │
│     calc_period_start   TIMESTAMP       │
│     calc_period_end     TIMESTAMP       │
│     balance_snapshot    JSONB           │  -- [{balance, start_time, end_time}]
│     points_earned       NUMERIC(20,10)  │
│     calculation_type    VARCHAR(20)     │  -- normal, backfill
│     created_at          TIMESTAMP       │
│ IDX (chain_name, user_address, calc_period_end) │
└─────────────────────────────────────────┘

┌─────────────────────────────────────────┐
│           sync_state                    │
│  同步状态表 (系统状态)                    │
├─────────────────────────────────────────┤
│ PK  id                  SERIAL          │
│     chain_name          VARCHAR(50)     │
│     last_synced_block   BIGINT          │
│     last_confirmed_block BIGINT         │  -- last_synced_block - 6
│     last_sync_at        TIMESTAMP       │
│     status              VARCHAR(20)     │  -- running, stopped, error
│     error_message       TEXT            │
│     created_at          TIMESTAMP       │
│     updated_at          TIMESTAMP       │
│ UK  (chain_name)                        │
└─────────────────────────────────────────┘
```

### 4.2 表设计详情

#### 4.2.1 user_balances (用户余额表)

```sql
CREATE TABLE user_balances (
    id BIGSERIAL PRIMARY KEY,
    chain_name VARCHAR(50) NOT NULL,
    user_address VARCHAR(42) NOT NULL,
    balance NUMERIC(78, 0) NOT NULL DEFAULT 0,
    created_at TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP NOT NULL DEFAULT NOW(),
    CONSTRAINT uk_user_balances_chain_address UNIQUE (chain_name, user_address)
);

CREATE INDEX idx_user_balances_chain ON user_balances(chain_name);
CREATE INDEX idx_user_balances_address ON user_balances(user_address);
CREATE INDEX idx_user_balances_updated_at ON user_balances(updated_at);
```

**说明**：
- 存储用户在各链上的当前余额
- `balance` 使用 NUMERIC(78,0) 存储 uint256（不丢失精度）
- 唯一约束确保每个用户在每条链上只有一条记录

#### 4.2.2 balance_changes (余额变动表)

```sql
CREATE TABLE balance_changes (
    id BIGSERIAL PRIMARY KEY,
    chain_name VARCHAR(50) NOT NULL,
    user_address VARCHAR(42) NOT NULL,
    change_type VARCHAR(20) NOT NULL, -- 'transfer_in', 'transfer_out', 'mint', 'burn'
    amount NUMERIC(78, 0) NOT NULL,
    balance_before NUMERIC(78, 0) NOT NULL,
    balance_after NUMERIC(78, 0) NOT NULL,
    tx_hash VARCHAR(66) NOT NULL,
    block_number BIGINT NOT NULL,
    block_timestamp TIMESTAMP NOT NULL,
    event_index INTEGER NOT NULL,
    confirmed BOOLEAN NOT NULL DEFAULT FALSE,
    created_at TIMESTAMP NOT NULL DEFAULT NOW(),
    CONSTRAINT uk_balance_changes_event UNIQUE (chain_name, tx_hash, event_index, user_address)
);

CREATE INDEX idx_balance_changes_user ON balance_changes(chain_name, user_address, created_at);
CREATE INDEX idx_balance_changes_block ON balance_changes(chain_name, block_number);
CREATE INDEX idx_balance_changes_confirmed ON balance_changes(confirmed);
CREATE INDEX idx_balance_changes_timestamp ON balance_changes(chain_name, block_timestamp);
```

**说明**：
- 记录每一次余额变动
- `confirmed` 字段标记是否已经过6个区块确认
- 唯一约束防止重复处理同一事件

#### 4.2.3 user_points (用户积分表)

```sql
CREATE TABLE user_points (
    id BIGSERIAL PRIMARY KEY,
    chain_name VARCHAR(50) NOT NULL,
    user_address VARCHAR(42) NOT NULL,
    total_points NUMERIC(20, 10) NOT NULL DEFAULT 0,
    last_calc_at TIMESTAMP,
    created_at TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP NOT NULL DEFAULT NOW(),
    CONSTRAINT uk_user_points_chain_address UNIQUE (chain_name, user_address)
);

CREATE INDEX idx_user_points_chain ON user_points(chain_name);
CREATE INDEX idx_user_points_last_calc ON user_points(last_calc_at);
```

**说明**：
- 存储用户累计积分
- `last_calc_at` 记录最后一次计算时间，用于增量计算

#### 4.2.4 points_history (积分历史表)

```sql
CREATE TABLE points_history (
    id BIGSERIAL PRIMARY KEY,
    chain_name VARCHAR(50) NOT NULL,
    user_address VARCHAR(42) NOT NULL,
    calc_period_start TIMESTAMP NOT NULL,
    calc_period_end TIMESTAMP NOT NULL,
    balance_snapshot JSONB NOT NULL, -- 分段余额快照
    points_earned NUMERIC(20, 10) NOT NULL,
    calculation_type VARCHAR(20) NOT NULL, -- 'normal', 'backfill'
    created_at TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_points_history_user ON points_history(chain_name, user_address, calc_period_end);
CREATE INDEX idx_points_history_period ON points_history(calc_period_start, calc_period_end);
```

**说明**：
- 记录每次积分计算的详细信息
- `balance_snapshot` 存储分段余额信息（JSONB格式）
- 支持审计和回溯验证

#### 4.2.5 sync_state (同步状态表)

```sql
CREATE TABLE sync_state (
    id SERIAL PRIMARY KEY,
    chain_name VARCHAR(50) NOT NULL UNIQUE,
    last_synced_block BIGINT NOT NULL DEFAULT 0,
    last_confirmed_block BIGINT NOT NULL DEFAULT 0,
    last_sync_at TIMESTAMP NOT NULL DEFAULT NOW(),
    status VARCHAR(20) NOT NULL DEFAULT 'stopped', -- 'running', 'stopped', 'error'
    error_message TEXT,
    created_at TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_sync_state_status ON sync_state(status);
```

**说明**：
- 记录每条链的同步状态
- 支持断点续传
- 记录运行状态和错误信息

---

## 5. 后端服务设计

### 5.1 项目结构

```
backend/
├── cmd/                          # 命令行入口
│   └── root.go                   # Cobra 根命令
│       ├── start.go              # 启动所有服务
│       ├── listener.go           # 启动事件监听
│       ├── calculator.go         # 启动积分计算
│       ├── api.go                # 启动API服务
│       └── migrate.go            # 数据库迁移
│
├── config/                       # 配置管理
│   ├── config.go                 # 配置结构定义
│   ├── dev.yaml                  # 开发环境配置
│   └── prod.yaml                 # 生产环境配置
│
├── internal/                     # 内部包
│   ├── api/                      # API层 (Gin)
│   │   ├── router.go             # 路由配置
│   │   ├── middleware/           # 中间件
│   │   │   ├── cors.go
│   │   │   ├── logger.go
│   │   │   └── recovery.go
│   │   └── handlers/             # 处理器
│   │       ├── balance.go        # 余额查询
│   │       ├── points.go         # 积分查询
│   │       ├── history.go        # 历史记录
│   │       └── health.go         # 健康检查
│   │
│   ├── service/                  # 业务逻辑层
│   │   ├── listener/             # 事件监听服务
│   │   │   ├── listener.go       # 监听器主逻辑
│   │   │   ├── event_parser.go   # 事件解析
│   │   │   └── confirmer.go      # 确认机制
│   │   ├── balance/              # 余额服务
│   │   │   └── balance_service.go
│   │   └── points/               # 积分服务
│   │       ├── calculator.go     # 积分计算
│   │       └── backfill.go       # 回溯计算
│   │
│   ├── repository/               # 数据访问层
│   │   ├── balance_repo.go       # 余额仓储
│   │   ├── points_repo.go        # 积分仓储
│   │   ├── sync_repo.go          # 同步状态仓储
│   │   └── tx_manager.go         # 事务管理
│   │
│   ├── model/                    # 数据模型
│   │   ├── balance.go            # 余额模型
│   │   ├── points.go             # 积分模型
│   │   └── sync.go               # 同步模型
│   │
│   └── pkg/                      # 共享包
│       ├── database/             # 数据库
│       │   └── postgres.go       # PostgreSQL连接
│       ├── blockchain/           # 区块链客户端
│       │   └── client.go         # Geth客户端封装
│       ├── logger/               # 日志
│       │   └── logger.go         # Logrus配置
│       └── contracts/            # 合约绑定
│           └── erc20.go          # ERC20合约Go绑定
│
├── migrations/                   # 数据库迁移
│   ├── 001_init_schema.up.sql
│   └── 001_init_schema.down.sql
│
├── main.go                       # 程序入口
├── go.mod                        # Go模块
└── go.sum                        # 依赖校验
```

### 5.2 配置管理 (Viper + YAML)

#### 5.2.1 配置文件结构

**config/dev.yaml**
```yaml
# 应用配置
app:
  name: "my-token-points"
  env: "dev"
  log_level: "debug"

# 数据库配置
database:
  host: "localhost"
  port: 5432
  user: "postgres"
  password: "postgres"
  dbname: "token_points_dev"
  sslmode: "disable"
  max_open_conns: 25
  max_idle_conns: 5
  conn_max_lifetime: 300  # 秒

# API服务配置
api:
  enabled: true
  host: "0.0.0.0"
  port: 8080
  cors:
    enabled: true
    allowed_origins: ["http://localhost:3000"]

# 区块链配置
chains:
  - name: "sepolia"
    chain_id: 11155111
    rpc_url: "https://sepolia.infura.io/v3/YOUR_KEY"
    contract_address: "0x..."
    start_block: 0  # 0表示从部署区块开始
    scan_interval: 12  # 秒
    batch_size: 1000  # 每次扫描区块数
    
  - name: "base_sepolia"
    chain_id: 84532
    rpc_url: "https://sepolia.base.org"
    contract_address: "0x..."
    start_block: 0
    scan_interval: 2  # Base链出块快
    batch_size: 1000

# 确认机制
confirmation:
  blocks: 6  # 延迟确认区块数

# 积分计算配置
points:
  enabled: true
  cron_schedule: "0 * * * *"  # 每小时执行
  annual_rate: 0.05  # 年化比率 5%
  backfill_on_startup: true  # 启动时自动回溯
  backfill_max_days: 30  # 最多回溯30天
```

**config/prod.yaml**
```yaml
app:
  name: "my-token-points"
  env: "prod"
  log_level: "info"

database:
  host: "${DB_HOST}"  # 支持环境变量
  port: 5432
  user: "${DB_USER}"
  password: "${DB_PASSWORD}"
  dbname: "token_points_prod"
  sslmode: "require"
  max_open_conns: 50
  max_idle_conns: 10
  conn_max_lifetime: 600

api:
  enabled: true
  host: "0.0.0.0"
  port: 8080
  cors:
    enabled: true
    allowed_origins: ["https://yourdomain.com"]

chains:
  - name: "sepolia"
    chain_id: 11155111
    rpc_url: "${SEPOLIA_RPC_URL}"
    contract_address: "${SEPOLIA_CONTRACT}"
    start_block: 0
    scan_interval: 12
    batch_size: 1000
    
  - name: "base_sepolia"
    chain_id: 84532
    rpc_url: "${BASE_SEPOLIA_RPC_URL}"
    contract_address: "${BASE_SEPOLIA_CONTRACT}"
    start_block: 0
    scan_interval: 2
    batch_size: 1000

confirmation:
  blocks: 6

points:
  enabled: true
  cron_schedule: "0 * * * *"
  annual_rate: 0.05
  backfill_on_startup: true
  backfill_max_days: 30
```

#### 5.2.2 配置加载代码

**config/config.go**
```go
package config

import (
    "fmt"
    "github.com/spf13/viper"
    "strings"
)

type Config struct {
    App         AppConfig         `mapstructure:"app"`
    Database    DatabaseConfig    `mapstructure:"database"`
    API         APIConfig         `mapstructure:"api"`
    Chains      []ChainConfig     `mapstructure:"chains"`
    Confirmation ConfirmationConfig `mapstructure:"confirmation"`
    Points      PointsConfig      `mapstructure:"points"`
}

type AppConfig struct {
    Name     string `mapstructure:"name"`
    Env      string `mapstructure:"env"`
    LogLevel string `mapstructure:"log_level"`
}

type DatabaseConfig struct {
    Host            string `mapstructure:"host"`
    Port            int    `mapstructure:"port"`
    User            string `mapstructure:"user"`
    Password        string `mapstructure:"password"`
    DBName          string `mapstructure:"dbname"`
    SSLMode         string `mapstructure:"sslmode"`
    MaxOpenConns    int    `mapstructure:"max_open_conns"`
    MaxIdleConns    int    `mapstructure:"max_idle_conns"`
    ConnMaxLifetime int    `mapstructure:"conn_max_lifetime"`
}

type APIConfig struct {
    Enabled bool       `mapstructure:"enabled"`
    Host    string     `mapstructure:"host"`
    Port    int        `mapstructure:"port"`
    CORS    CORSConfig `mapstructure:"cors"`
}

type CORSConfig struct {
    Enabled        bool     `mapstructure:"enabled"`
    AllowedOrigins []string `mapstructure:"allowed_origins"`
}

type ChainConfig struct {
    Name            string `mapstructure:"name"`
    ChainID         int64  `mapstructure:"chain_id"`
    RPCURL          string `mapstructure:"rpc_url"`
    ContractAddress string `mapstructure:"contract_address"`
    StartBlock      uint64 `mapstructure:"start_block"`
    ScanInterval    int    `mapstructure:"scan_interval"`
    BatchSize       uint64 `mapstructure:"batch_size"`
}

type ConfirmationConfig struct {
    Blocks uint64 `mapstructure:"blocks"`
}

type PointsConfig struct {
    Enabled            bool    `mapstructure:"enabled"`
    CronSchedule       string  `mapstructure:"cron_schedule"`
    AnnualRate         float64 `mapstructure:"annual_rate"`
    BackfillOnStartup  bool    `mapstructure:"backfill_on_startup"`
    BackfillMaxDays    int     `mapstructure:"backfill_max_days"`
}

// LoadConfig 加载配置
func LoadConfig(configPath string, env string) (*Config, error) {
    v := viper.New()
    
    // 设置配置文件
    v.SetConfigName(env)  // dev.yaml 或 prod.yaml
    v.SetConfigType("yaml")
    v.AddConfigPath(configPath)
    v.AddConfigPath("./config")
    v.AddConfigPath(".")
    
    // 支持环境变量
    v.AutomaticEnv()
    v.SetEnvKeyReplacer(strings.NewReplacer(".", "_"))
    
    // 读取配置
    if err := v.ReadInConfig(); err != nil {
        return nil, fmt.Errorf("failed to read config: %w", err)
    }
    
    // 解析配置
    var config Config
    if err := v.Unmarshal(&config); err != nil {
        return nil, fmt.Errorf("failed to unmarshal config: %w", err)
    }
    
    // 验证配置
    if err := validateConfig(&config); err != nil {
        return nil, fmt.Errorf("invalid config: %w", err)
    }
    
    return &config, nil
}

// validateConfig 验证配置
func validateConfig(config *Config) error {
    if config.Database.Host == "" {
        return fmt.Errorf("database host is required")
    }
    if len(config.Chains) == 0 {
        return fmt.Errorf("at least one chain is required")
    }
    for _, chain := range config.Chains {
        if chain.RPCURL == "" {
            return fmt.Errorf("rpc_url is required for chain %s", chain.Name)
        }
        if chain.ContractAddress == "" {
            return fmt.Errorf("contract_address is required for chain %s", chain.Name)
        }
    }
    return nil
}
```

### 5.3 Cobra 命令设计

#### 5.3.1 根命令 (cmd/root.go)

```go
package cmd

import (
    "fmt"
    "github.com/spf13/cobra"
    "os"
)

var (
    cfgFile string
    env     string
)

var rootCmd = &cobra.Command{
    Use:   "my-token-points",
    Short: "多链ERC20代币积分系统",
    Long: `
多链ERC20代币事件追踪和积分计算系统

支持功能：
  - 追踪代币事件(Transfer, Mint, Burn)
  - 重建用户余额
  - 基于持有时间计算积分
  - 支持多链部署
  - 支持积分回溯
`,
}

func Execute() {
    if err := rootCmd.Execute(); err != nil {
        fmt.Println(err)
        os.Exit(1)
    }
}

func init() {
    rootCmd.PersistentFlags().StringVar(&cfgFile, "config", "", "配置文件路径 (默认: ./config)")
    rootCmd.PersistentFlags().StringVar(&env, "env", "dev", "环境 (dev/prod)")
}
```

#### 5.3.2 启动所有服务 (cmd/start.go)

```go
package cmd

import (
    "context"
    "github.com/spf13/cobra"
    "log"
    "os"
    "os/signal"
    "sync"
    "syscall"
)

var startCmd = &cobra.Command{
    Use:   "start",
    Short: "启动所有服务",
    Long:  "启动事件监听、积分计算和API服务",
    Run: func(cmd *cobra.Command, args []string) {
        // 加载配置
        cfg, err := config.LoadConfig(cfgFile, env)
        if err != nil {
            log.Fatalf("Failed to load config: %v", err)
        }
        
        // 初始化日志
        logger := pkg.InitLogger(cfg.App.LogLevel)
        logger.Info("Starting my-token-points service...")
        
        // 初始化数据库
        db, err := pkg.InitDatabase(cfg.Database)
        if err != nil {
            logger.Fatalf("Failed to init database: %v", err)
        }
        defer db.Close()
        
        // 创建上下文
        ctx, cancel := context.WithCancel(context.Background())
        defer cancel()
        
        var wg sync.WaitGroup
        
        // 启动事件监听服务
        for _, chainCfg := range cfg.Chains {
            wg.Add(1)
            go func(chain config.ChainConfig) {
                defer wg.Done()
                listenerSvc := service.NewListenerService(db, cfg, chain, logger)
                if err := listenerSvc.Start(ctx); err != nil {
                    logger.Errorf("Listener service failed for %s: %v", chain.Name, err)
                }
            }(chainCfg)
        }
        
        // 启动积分计算服务
        if cfg.Points.Enabled {
            wg.Add(1)
            go func() {
                defer wg.Done()
                pointsSvc := service.NewPointsService(db, cfg, logger)
                if err := pointsSvc.Start(ctx); err != nil {
                    logger.Errorf("Points service failed: %v", err)
                }
            }()
        }
        
        // 启动API服务
        if cfg.API.Enabled {
            wg.Add(1)
            go func() {
                defer wg.Done()
                apiSvc := api.NewAPIService(db, cfg, logger)
                if err := apiSvc.Start(ctx); err != nil {
                    logger.Errorf("API service failed: %v", err)
                }
            }()
        }
        
        // 等待中断信号
        sigChan := make(chan os.Signal, 1)
        signal.Notify(sigChan, syscall.SIGINT, syscall.SIGTERM)
        <-sigChan
        
        logger.Info("Shutting down gracefully...")
        cancel()
        wg.Wait()
        logger.Info("Shutdown complete")
    },
}

func init() {
    rootCmd.AddCommand(startCmd)
}
```

#### 5.3.3 其他命令

```go
// cmd/listener.go - 仅启动事件监听
var listenerCmd = &cobra.Command{
    Use:   "listener",
    Short: "启动事件监听服务",
    Run: func(cmd *cobra.Command, args []string) {
        // 实现
    },
}

// cmd/calculator.go - 仅启动积分计算
var calculatorCmd = &cobra.Command{
    Use:   "calculator",
    Short: "启动积分计算服务",
    Run: func(cmd *cobra.Command, args []string) {
        // 实现
    },
}

// cmd/api.go - 仅启动API服务
var apiCmd = &cobra.Command{
    Use:   "api",
    Short: "启动API服务",
    Run: func(cmd *cobra.Command, args []string) {
        // 实现
    },
}

// cmd/migrate.go - 数据库迁移
var migrateCmd = &cobra.Command{
    Use:   "migrate",
    Short: "数据库迁移",
    Run: func(cmd *cobra.Command, args []string) {
        // 实现
    },
}
```

---

## 6. 核心业务逻辑

### 6.1 事件监听服务

#### 6.1.1 监听流程

```
┌─────────────────────────────────────────────────────┐
│            事件监听主循环                              │
└─────────────────────────────────────────────────────┘
                        │
                        ▼
        ┌───────────────────────────┐
        │  1. 获取同步状态            │
        │  - last_synced_block       │
        └───────────┬───────────────┘
                    │
                    ▼
        ┌───────────────────────────┐
        │  2. 获取最新区块号          │
        │  - eth_blockNumber         │
        └───────────┬───────────────┘
                    │
                    ▼
        ┌───────────────────────────┐
        │  3. 计算扫描范围            │
        │  - fromBlock = last + 1    │
        │  - toBlock = min(latest,   │
        │              from + 999)   │
        └───────────┬───────────────┘
                    │
                    ▼
        ┌───────────────────────────┐
        │  4. 批量获取日志            │
        │  - eth_getLogs             │
        │  - Filter by contract      │
        └───────────┬───────────────┘
                    │
                    ▼
        ┌───────────────────────────┐
        │  5. 解析事件               │
        │  - Transfer                │
        │  - TokenMinted             │
        │  - TokenBurned             │
        └───────────┬───────────────┘
                    │
                    ▼
        ┌───────────────────────────┐
        │  6. 开始数据库事务          │
        └───────────┬───────────────┘
                    │
                    ▼
        ┌───────────────────────────┐
        │  7. 更新用户余额            │
        │  - balance_before          │
        │  - balance_after           │
        └───────────┬───────────────┘
                    │
                    ▼
        ┌───────────────────────────┐
        │  8. 记录余额变动            │
        │  - balance_changes         │
        │  - confirmed = false       │
        └───────────┬───────────────┘
                    │
                    ▼
        ┌───────────────────────────┐
        │  9. 提交事务               │
        └───────────┬───────────────┘
                    │
                    ▼
        ┌───────────────────────────┐
        │  10. 更新同步状态           │
        │  - last_synced_block       │
        └───────────┬───────────────┘
                    │
                    ▼
        ┌───────────────────────────┐
        │  11. 确认旧区块             │
        │  - confirmed = true        │
        │    (block <= current - 6)  │
        └───────────┬───────────────┘
                    │
                    ▼
        ┌───────────────────────────┐
        │  12. 等待下一轮             │
        │  - sleep(scan_interval)    │
        └───────────────────────────┘
                    │
                    └──────┐
                           │
                    (循环回到步骤1)
```

#### 6.1.2 事件解析逻辑

**Transfer 事件处理**
```go
func (l *ListenerService) handleTransferEvent(
    ctx context.Context,
    log types.Log,
    tx *sqlx.Tx,
) error {
    // 解析事件
    event, err := l.contract.ParseTransfer(log)
    if err != nil {
        return err
    }
    
    // 获取区块时间
    block, err := l.client.BlockByNumber(ctx, big.NewInt(int64(log.BlockNumber)))
    if err != nil {
        return err
    }
    
    // 排除 mint (from == 0x0)
    if event.From != common.HexToAddress("0x0") {
        // 处理转出
        if err := l.processBalanceChange(ctx, tx, BalanceChange{
            ChainName:      l.chainName,
            UserAddress:    event.From.Hex(),
            ChangeType:     "transfer_out",
            Amount:         event.Value,
            TxHash:         log.TxHash.Hex(),
            BlockNumber:    log.BlockNumber,
            BlockTimestamp: time.Unix(int64(block.Time()), 0),
            EventIndex:     log.Index,
            Confirmed:      false,
        }); err != nil {
            return err
        }
    }
    
    // 排除 burn (to == 0x0)
    if event.To != common.HexToAddress("0x0") {
        // 处理转入
        if err := l.processBalanceChange(ctx, tx, BalanceChange{
            ChainName:      l.chainName,
            UserAddress:    event.To.Hex(),
            ChangeType:     "transfer_in",
            Amount:         event.Value,
            TxHash:         log.TxHash.Hex(),
            BlockNumber:    log.BlockNumber,
            BlockTimestamp: time.Unix(int64(block.Time()), 0),
            EventIndex:     log.Index,
            Confirmed:      false,
        }); err != nil {
            return err
        }
    }
    
    return nil
}
```

**TokenMinted 事件处理**
```go
func (l *ListenerService) handleMintEvent(
    ctx context.Context,
    log types.Log,
    tx *sqlx.Tx,
) error {
    event, err := l.contract.ParseTokenMinted(log)
    if err != nil {
        return err
    }
    
    return l.processBalanceChange(ctx, tx, BalanceChange{
        ChainName:      l.chainName,
        UserAddress:    event.To.Hex(),
        ChangeType:     "mint",
        Amount:         event.Amount,
        TxHash:         log.TxHash.Hex(),
        BlockNumber:    log.BlockNumber,
        BlockTimestamp: time.Unix(int64(event.Timestamp), 0),
        EventIndex:     log.Index,
        Confirmed:      false,
    })
}
```

**TokenBurned 事件处理**
```go
func (l *ListenerService) handleBurnEvent(
    ctx context.Context,
    log types.Log,
    tx *sqlx.Tx,
) error {
    event, err := l.contract.ParseTokenBurned(log)
    if err != nil {
        return err
    }
    
    return l.processBalanceChange(ctx, tx, BalanceChange{
        ChainName:      l.chainName,
        UserAddress:    event.From.Hex(),
        ChangeType:     "burn",
        Amount:         new(big.Int).Neg(event.Amount), // 负数
        TxHash:         log.TxHash.Hex(),
        BlockNumber:    log.BlockNumber,
        BlockTimestamp: time.Unix(int64(event.Timestamp), 0),
        EventIndex:     log.Index,
        Confirmed:      false,
    })
}
```

#### 6.1.3 余额更新逻辑

```go
func (l *ListenerService) processBalanceChange(
    ctx context.Context,
    tx *sqlx.Tx,
    change BalanceChange,
) error {
    // 1. 获取当前余额
    balance, err := l.balanceRepo.GetBalance(ctx, tx, change.ChainName, change.UserAddress)
    if err != nil {
        return err
    }
    
    // 2. 计算新余额
    var newBalance *big.Int
    if change.ChangeType == "burn" || change.ChangeType == "transfer_out" {
        newBalance = new(big.Int).Sub(balance, change.Amount)
    } else {
        newBalance = new(big.Int).Add(balance, change.Amount)
    }
    
    // 3. 检查余额是否合法
    if newBalance.Sign() < 0 {
        return fmt.Errorf("negative balance for %s", change.UserAddress)
    }
    
    // 4. 记录余额变动
    change.BalanceBefore = balance
    change.BalanceAfter = newBalance
    if err := l.balanceRepo.RecordChange(ctx, tx, change); err != nil {
        return err
    }
    
    // 5. 更新用户余额
    if err := l.balanceRepo.UpdateBalance(ctx, tx, change.ChainName, change.UserAddress, newBalance); err != nil {
        return err
    }
    
    return nil
}
```

#### 6.1.4 确认机制

```go
func (l *ListenerService) confirmOldBlocks(ctx context.Context) error {
    // 获取最新区块
    latestBlock, err := l.client.BlockNumber(ctx)
    if err != nil {
        return err
    }
    
    // 计算确认区块号
    if latestBlock < l.config.Confirmation.Blocks {
        return nil // 区块数不够
    }
    
    confirmedBlock := latestBlock - l.config.Confirmation.Blocks
    
    // 更新数据库
    return l.balanceRepo.ConfirmBalanceChanges(ctx, l.chainName, confirmedBlock)
}
```

### 6.2 积分计算服务

#### 6.2.1 计算流程

```
┌─────────────────────────────────────────────────────┐
│            积分计算定时任务                            │
│            Cron: "0 * * * *" (每小时)                 │
└─────────────────────────────────────────────────────┘
                        │
                        ▼
        ┌───────────────────────────┐
        │  1. 获取所有用户列表        │
        │  - 查询 user_balances       │
        │  - 按链分组                │
        └───────────┬───────────────┘
                    │
                    ▼
        ┌───────────────────────────┐
        │  2. 对每个用户计算          │
        │  - 并发处理                │
        └───────────┬───────────────┘
                    │
                    ▼
        ┌───────────────────────────┐
        │  3. 确定计算时间范围        │
        │  - start: last_calc_at     │
        │  - end: now                │
        └───────────┬───────────────┘
                    │
                    ▼
        ┌───────────────────────────┐
        │  4. 获取余额变动记录        │
        │  - WHERE confirmed=true    │
        │  - ORDER BY timestamp      │
        └───────────┬───────────────┘
                    │
                    ▼
        ┌───────────────────────────┐
        │  5. 构建余额时间线          │
        │  - 分段计算                │
        │  [{balance, start, end}]   │
        └───────────┬───────────────┘
                    │
                    ▼
        ┌───────────────────────────┐
        │  6. 计算每段积分            │
        │  points = balance *        │
        │    hours * rate / 8760     │
        └───────────┬───────────────┘
                    │
                    ▼
        ┌───────────────────────────┐
        │  7. 累加总积分              │
        └───────────┬───────────────┘
                    │
                    ▼
        ┌───────────────────────────┐
        │  8. 开始数据库事务          │
        └───────────┬───────────────┘
                    │
                    ▼
        ┌───────────────────────────┐
        │  9. 更新用户积分            │
        │  - total_points += earned  │
        │  - last_calc_at = now      │
        └───────────┬───────────────┘
                    │
                    ▼
        ┌───────────────────────────┐
        │  10. 记录计算历史           │
        │  - points_history          │
        └───────────┬───────────────┘
                    │
                    ▼
        ┌───────────────────────────┐
        │  11. 提交事务              │
        └───────────────────────────┘
```

#### 6.2.2 积分计算算法

**示例场景**：
- 15:00 - 0 个 token
- 15:10 - 100 个 token (mint)
- 15:30 - 200 个 token (transfer in +100)
- 16:00 - 计算积分

**计算逻辑**：
```go
func (p *PointsService) calculatePoints(
    chainName, userAddress string,
    startTime, endTime time.Time,
) (float64, []BalanceSnapshot, error) {
    
    // 1. 获取时间段内的余额变动(仅已确认)
    changes, err := p.balanceRepo.GetBalanceChanges(
        chainName,
        userAddress,
        startTime,
        endTime,
        true, // 仅已确认
    )
    if err != nil {
        return 0, nil, err
    }
    
    // 2. 构建余额时间线
    snapshots := []BalanceSnapshot{}
    currentBalance := big.NewInt(0)
    currentTime := startTime
    
    // 如果有历史余额,获取起始余额
    if len(changes) > 0 {
        currentBalance = changes[0].BalanceBefore
    }
    
    for _, change := range changes {
        // 记录当前余额段
        if change.BlockTimestamp.After(currentTime) {
            snapshots = append(snapshots, BalanceSnapshot{
                Balance:   new(big.Int).Set(currentBalance),
                StartTime: currentTime,
                EndTime:   change.BlockTimestamp,
            })
            currentTime = change.BlockTimestamp
        }
        
        // 更新余额
        currentBalance = change.BalanceAfter
    }
    
    // 最后一段(最后变动到结束时间)
    if currentTime.Before(endTime) {
        snapshots = append(snapshots, BalanceSnapshot{
            Balance:   new(big.Int).Set(currentBalance),
            StartTime: currentTime,
            EndTime:   endTime,
        })
    }
    
    // 3. 计算每段积分
    totalPoints := 0.0
    for _, snap := range snapshots {
        duration := snap.EndTime.Sub(snap.StartTime).Hours()
        balanceFloat := new(big.Float).SetInt(snap.Balance)
        balanceFloat.Quo(balanceFloat, big.NewFloat(1e18)) // 转换为token单位
        
        // 积分 = 余额 * 持有时间(小时) * 年化比率 / 8760
        points := balanceFloat.Mul(
            balanceFloat,
            big.NewFloat(duration * p.config.Points.AnnualRate / 8760),
        )
        
        pointsFloat, _ := points.Float64()
        totalPoints += pointsFloat
    }
    
    return totalPoints, snapshots, nil
}
```

**具体示例计算**：

```
时间段1: 15:00 - 15:10 (0 tokens)
  points1 = 0 * (10/60) * 0.05 = 0

时间段2: 15:10 - 15:30 (100 tokens)
  points2 = 100 * (20/60) * 0.05 = 1.667

时间段3: 15:30 - 16:00 (200 tokens)
  points3 = 200 * (30/60) * 0.05 = 5.0

总积分 = 0 + 1.667 + 5.0 = 6.667
```

#### 6.2.3 积分回溯机制

**场景**：程序停止3天,重启后需要回溯计算

```go
func (p *PointsService) backfillPoints(ctx context.Context) error {
    logger := p.logger.WithField("component", "backfill")
    logger.Info("Starting points backfill...")
    
    // 1. 获取所有用户
    users, err := p.pointsRepo.GetAllUsers(ctx)
    if err != nil {
        return err
    }
    
    for _, user := range users {
        // 2. 确定回溯时间范围
        lastCalcAt := user.LastCalcAt
        if lastCalcAt.IsZero() {
            // 首次计算,从第一笔交易开始
            firstChange, err := p.balanceRepo.GetFirstBalanceChange(
                user.ChainName,
                user.UserAddress,
            )
            if err != nil {
                continue
            }
            lastCalcAt = firstChange.BlockTimestamp
        }
        
        now := time.Now()
        
        // 3. 限制回溯范围
        maxBackfillDuration := time.Duration(p.config.Points.BackfillMaxDays) * 24 * time.Hour
        if now.Sub(lastCalcAt) > maxBackfillDuration {
            logger.Warnf("Backfill duration exceeds max for user %s, limiting to %d days",
                user.UserAddress, p.config.Points.BackfillMaxDays)
            lastCalcAt = now.Add(-maxBackfillDuration)
        }
        
        // 4. 按小时分段回溯
        currentTime := lastCalcAt
        for currentTime.Before(now) {
            nextTime := currentTime.Add(time.Hour)
            if nextTime.After(now) {
                nextTime = now
            }
            
            // 计算这一小时的积分
            points, snapshots, err := p.calculatePoints(
                user.ChainName,
                user.UserAddress,
                currentTime,
                nextTime,
            )
            if err != nil {
                logger.Errorf("Failed to calculate points for user %s: %v",
                    user.UserAddress, err)
                continue
            }
            
            // 保存计算结果
            if err := p.savePointsCalculation(ctx, PointsCalculation{
                ChainName:        user.ChainName,
                UserAddress:      user.UserAddress,
                CalcPeriodStart:  currentTime,
                CalcPeriodEnd:    nextTime,
                BalanceSnapshot:  snapshots,
                PointsEarned:     points,
                CalculationType:  "backfill",
            }); err != nil {
                logger.Errorf("Failed to save points calculation: %v", err)
                continue
            }
            
            currentTime = nextTime
        }
        
        logger.Infof("Backfilled points for user %s from %s to %s",
            user.UserAddress, lastCalcAt.Format(time.RFC3339), now.Format(time.RFC3339))
    }
    
    logger.Info("Points backfill completed")
    return nil
}
```

**回溯特点**：
1. 自动检测距离上次计算的时间
2. 按小时分段计算(保持与定时任务一致)
3. 限制最大回溯天数(防止计算量过大)
4. 记录计算类型为 `backfill`
5. 支持启动时自动回溯或手动触发

---

## 7. API 设计 (Gin Framework)

### 7.1 API 路由

```go
// internal/api/router.go
func SetupRouter(db *sqlx.DB, cfg *config.Config, logger *logrus.Logger) *gin.Engine {
    // 设置模式
    if cfg.App.Env == "prod" {
        gin.SetMode(gin.ReleaseMode)
    }
    
    r := gin.New()
    
    // 中间件
    r.Use(middleware.Logger(logger))
    r.Use(middleware.Recovery(logger))
    if cfg.API.CORS.Enabled {
        r.Use(middleware.CORS(cfg.API.CORS))
    }
    
    // 初始化处理器
    balanceHandler := handlers.NewBalanceHandler(db, logger)
    pointsHandler := handlers.NewPointsHandler(db, logger)
    historyHandler := handlers.NewHistoryHandler(db, logger)
    healthHandler := handlers.NewHealthHandler(db, logger)
    
    // 健康检查
    r.GET("/health", healthHandler.HealthCheck)
    r.GET("/ready", healthHandler.ReadyCheck)
    
    // API v1
    v1 := r.Group("/api/v1")
    {
        // 余额查询
        v1.GET("/balances/:chain/:address", balanceHandler.GetBalance)
        v1.GET("/balances/:chain", balanceHandler.GetAllBalances)
        
        // 积分查询
        v1.GET("/points/:chain/:address", pointsHandler.GetPoints)
        v1.GET("/points/:chain", pointsHandler.GetAllPoints)
        v1.GET("/points/:chain/:address/leaderboard", pointsHandler.GetLeaderboard)
        
        // 历史记录
        v1.GET("/history/balance-changes/:chain/:address", historyHandler.GetBalanceChanges)
        v1.GET("/history/points-calculations/:chain/:address", historyHandler.GetPointsHistory)
        
        // 统计信息
        v1.GET("/stats/:chain", historyHandler.GetChainStats)
        
        // 同步状态
        v1.GET("/sync/status", historyHandler.GetSyncStatus)
        v1.GET("/sync/status/:chain", historyHandler.GetChainSyncStatus)
    }
    
    return r
}
```

### 7.2 API 接口列表

#### 7.2.1 余额相关

**获取用户余额**
```
GET /api/v1/balances/:chain/:address

Response:
{
  "code": 0,
  "message": "success",
  "data": {
    "chain_name": "sepolia",
    "user_address": "0x123...",
    "balance": "1000000000000000000",  // wei
    "balance_formatted": "1.0",        // token
    "updated_at": "2024-01-01T12:00:00Z"
  }
}
```

**获取链上所有余额**
```
GET /api/v1/balances/:chain?page=1&limit=20

Response:
{
  "code": 0,
  "message": "success",
  "data": {
    "total": 100,
    "page": 1,
    "limit": 20,
    "balances": [
      {
        "user_address": "0x123...",
        "balance": "1000000000000000000",
        "balance_formatted": "1.0"
      }
    ]
  }
}
```

#### 7.2.2 积分相关

**获取用户积分**
```
GET /api/v1/points/:chain/:address

Response:
{
  "code": 0,
  "message": "success",
  "data": {
    "chain_name": "sepolia",
    "user_address": "0x123...",
    "total_points": "123.4567",
    "last_calc_at": "2024-01-01T12:00:00Z"
  }
}
```

**积分排行榜**
```
GET /api/v1/points/:chain/leaderboard?limit=10

Response:
{
  "code": 0,
  "message": "success",
  "data": {
    "leaderboard": [
      {
        "rank": 1,
        "user_address": "0x123...",
        "total_points": "999.99"
      }
    ]
  }
}
```

#### 7.2.3 历史记录

**获取余额变动历史**
```
GET /api/v1/history/balance-changes/:chain/:address?page=1&limit=20

Response:
{
  "code": 0,
  "message": "success",
  "data": {
    "total": 50,
    "page": 1,
    "limit": 20,
    "changes": [
      {
        "change_type": "transfer_in",
        "amount": "100000000000000000",
        "balance_before": "0",
        "balance_after": "100000000000000000",
        "tx_hash": "0xabc...",
        "block_number": 12345,
        "block_timestamp": "2024-01-01T12:00:00Z",
        "confirmed": true
      }
    ]
  }
}
```

**获取积分计算历史**
```
GET /api/v1/history/points-calculations/:chain/:address?page=1&limit=20

Response:
{
  "code": 0,
  "message": "success",
  "data": {
    "total": 100,
    "page": 1,
    "limit": 20,
    "calculations": [
      {
        "calc_period_start": "2024-01-01T11:00:00Z",
        "calc_period_end": "2024-01-01T12:00:00Z",
        "balance_snapshot": [
          {
            "balance": "100000000000000000",
            "start_time": "2024-01-01T11:00:00Z",
            "end_time": "2024-01-01T12:00:00Z"
          }
        ],
        "points_earned": "0.5708",
        "calculation_type": "normal"
      }
    ]
  }
}
```

#### 7.2.4 系统状态

**同步状态**
```
GET /api/v1/sync/status

Response:
{
  "code": 0,
  "message": "success",
  "data": {
    "chains": [
      {
        "chain_name": "sepolia",
        "last_synced_block": 12345,
        "last_confirmed_block": 12339,
        "last_sync_at": "2024-01-01T12:00:00Z",
        "status": "running"
      }
    ]
  }
}
```

**健康检查**
```
GET /health

Response:
{
  "status": "healthy",
  "timestamp": "2024-01-01T12:00:00Z"
}
```

---

## 8. 部署方案

### 8.1 环境要求

| 组件 | 版本要求 | 说明 |
|------|---------|------|
| Go | 1.21+ | 后端运行环境 |
| PostgreSQL | 17 | 数据库 |
| Node.js | 18+ | 合约部署 |
| Hardhat | 2.19+ | 智能合约框架 |

### 8.2 部署步骤

#### 8.2.1 部署智能合约

```bash
# 1. 进入合约目录
cd contracts

# 2. 安装依赖
npm install

# 3. 编译合约
npx hardhat compile

# 4. 部署到 Sepolia
npx hardhat run scripts/deploy.js --network sepolia

# 5. 部署到 Base Sepolia
npx hardhat run scripts/deploy.js --network base_sepolia

# 6. 记录合约地址
```

#### 8.2.2 初始化数据库

```bash
# 1. 创建数据库
createdb -U postgres token_points_prod

# 2. 执行迁移
cd backend
go run main.go migrate --env prod --config ./config
```

#### 8.2.3 配置后端服务

```bash
# 1. 复制配置文件
cp config/prod.yaml.example config/prod.yaml

# 2. 编辑配置
vim config/prod.yaml

# 填入：
# - 数据库连接信息
# - RPC节点URL
# - 合约地址
# - 其他参数

# 3. 设置环境变量(敏感信息)
export DB_PASSWORD="your_password"
export SEPOLIA_RPC_URL="https://..."
export BASE_SEPOLIA_RPC_URL="https://..."
```

#### 8.2.4 编译和运行

```bash
# 1. 编译
go build -o my-token-points main.go

# 2. 运行
./my-token-points start --env prod --config ./config
```

### 8.3 Docker 部署

**Dockerfile**
```dockerfile
FROM golang:1.21-alpine AS builder

WORKDIR /app
COPY go.* ./
RUN go mod download

COPY . .
RUN go build -o my-token-points main.go

FROM alpine:latest
RUN apk --no-cache add ca-certificates

WORKDIR /root/
COPY --from=builder /app/my-token-points .
COPY --from=builder /app/config ./config

EXPOSE 8080

CMD ["./my-token-points", "start", "--env", "prod"]
```

**docker-compose.yml**
```yaml
version: '3.8'

services:
  postgres:
    image: postgres:17-alpine
    environment:
      POSTGRES_DB: token_points
      POSTGRES_USER: postgres
      POSTGRES_PASSWORD: ${DB_PASSWORD}
    ports:
      - "5432:5432"
    volumes:
      - postgres_data:/var/lib/postgresql/data
    healthcheck:
      test: ["CMD", "pg_isready", "-U", "postgres"]
      interval: 10s
      timeout: 5s
      retries: 5

  backend:
    build: .
    depends_on:
      postgres:
        condition: service_healthy
    environment:
      DB_HOST: postgres
      DB_PASSWORD: ${DB_PASSWORD}
      SEPOLIA_RPC_URL: ${SEPOLIA_RPC_URL}
      BASE_SEPOLIA_RPC_URL: ${BASE_SEPOLIA_RPC_URL}
    ports:
      - "8080:8080"
    restart: unless-stopped

volumes:
  postgres_data:
```

### 8.4 systemd 服务

**/etc/systemd/system/my-token-points.service**
```ini
[Unit]
Description=My Token Points Service
After=network.target postgresql.service

[Service]
Type=simple
User=app
WorkingDirectory=/opt/my-token-points
Environment="ENV=prod"
ExecStart=/opt/my-token-points/my-token-points start --env prod --config /opt/my-token-points/config
Restart=on-failure
RestartSec=10s

[Install]
WantedBy=multi-user.target
```

```bash
# 启用服务
sudo systemctl enable my-token-points
sudo systemctl start my-token-points

# 查看状态
sudo systemctl status my-token-points

# 查看日志
sudo journalctl -u my-token-points -f
```

---

## 9. 安全考虑

### 9.1 数据安全

1. **敏感信息管理**
   - 私钥和密码使用环境变量
   - 不提交到版本控制
   - 使用 secrets 管理工具

2. **API安全**
   - CORS 限制
   - 速率限制
   - 输入验证
   - SQL 注入防护(使用参数化查询)

### 9.2 区块链安全

1. **6区块确认机制**
   - 防止短期分叉
   - 只有确认的数据参与积分计算

2. **地址验证**
   ```go
   func isValidAddress(addr string) bool {
       return common.IsHexAddress(addr)
   }
   ```

3. **重放攻击防护**
   - 使用 (chain_name, tx_hash, event_index, user_address) 唯一约束
   - 防止同一事件被重复处理

---

## 10. 性能优化

### 10.1 数据库优化

1. **索引策略**
   ```sql
   -- 复合索引
   CREATE INDEX idx_balance_changes_user_time 
   ON balance_changes(chain_name, user_address, block_timestamp);
   
   -- 部分索引
   CREATE INDEX idx_unconfirmed 
   ON balance_changes(block_number) 
   WHERE confirmed = false;
   ```

2. **连接池配置**
   ```yaml
   database:
     max_open_conns: 50
     max_idle_conns: 10
     conn_max_lifetime: 600
   ```

3. **批量操作**
   - 批量插入 balance_changes
   - 批量更新确认状态

### 10.2 并发处理

1. **多链并发**
   - 每条链独立 goroutine
   - 互不影响

2. **积分计算并发**
   ```go
   var wg sync.WaitGroup
   for _, user := range users {
       wg.Add(1)
       go func(u User) {
           defer wg.Done()
           calculatePoints(u)
       }(user)
   }
   wg.Wait()
   ```

---

## 11. 测试策略

### 11.1 单元测试

```go
// repository/balance_repo_test.go
func TestGetBalance(t *testing.T) {
    // 使用 sqlmock 测试数据库操作
}

// service/points_test.go
func TestCalculatePoints(t *testing.T) {
    // 测试积分计算逻辑
}
```

### 11.2 集成测试

```bash
# 使用测试数据库
export ENV=test
go test ./... -v
```

### 11.3 端到端测试

```javascript
// 部署合约到本地测试网
npx hardhat node

// 执行测试交易
npx hardhat run scripts/interact.js --network localhost

// 验证后端数据
curl http://localhost:8080/api/v1/balances/localhost/0x123...
```

---

## 12. 扩展性考虑

### 12.1 水平扩展

1. **多实例部署**
   - 每条链可以独立实例
   - 通过 chain_name 分片

2. **数据库分片**
   - 按 chain_name 分库
   - 使用 Citus 或手动分片

### 12.2 功能扩展

1. **添加新链**
   - 只需在配置文件添加
   - 无需修改代码

2. **复杂积分规则**
   - 阶梯式计算
   - VIP倍率
   - 活动加成

3. **通知功能**
   - Webhook
   - Email
   - Telegram Bot

---

## 13. 里程碑和交付物

### 13.1 第一阶段 (1-2周)

**交付物**：
- ✅ 智能合约开发和部署
- ✅ 数据库设计和初始化
- ✅ 事件监听服务
- ✅ 余额重建功能

**验收标准**：
- 合约成功部署到测试网
- 能够监听和解析事件
- 余额数据正确更新

### 13.2 第二阶段 (1周)

**交付物**：
- ✅ 积分计算服务
- ✅ 定时任务
- ✅ 积分回溯功能

**验收标准**：
- 积分计算正确
- 定时任务稳定运行
- 回溯功能正常

### 13.3 第三阶段 (1周)

**交付物**：
- ✅ API 服务
- ✅ 多链支持
- ✅ 配置管理

**验收标准**：
- API 接口完整
- 支持 Sepolia 和 Base Sepolia
- 配置灵活

### 13.4 第四阶段 (1周)

**交付物**：
- ✅ 文档完善
- ✅ 部署脚本
- ✅ 监控告警

**验收标准**：
- 文档完整
- 一键部署
- 监控覆盖

---

## 14. 风险评估

| 风险 | 等级 | 应对措施 |
|------|------|---------|
| RPC 节点不稳定 | 高 | 配置备用 RPC,自动切换 |
| 区块链分叉 | 中 | 6区块确认机制 |
| 数据库故障 | 高 | 定期备份,主从复制 |
| 积分计算错误 | 高 | 详细测试,历史记录审计 |
| 服务中断 | 中 | 断点续传,自动重启 |
| 性能瓶颈 | 中 | 监控指标,优化查询 |

---

## 15. 总结

本技术方案完整地覆盖了项目的所有需求：

### 15.1 核心功能
✅ ERC20 合约 (mint/burn)  
✅ 事件监听和余额重建  
✅ 6区块延迟确认  
✅ 积分计算 (基于时间和余额)  
✅ 积分回溯 (处理中断场景)  
✅ 多链支持 (Sepolia, Base Sepolia)  
✅ 完整的数据记录  

### 15.2 技术栈
✅ Go + Gin + sqlx + Cobra + Viper  
✅ PostgreSQL 17  
✅ YAML 配置 (dev/prod环境分离)  
✅ Solidity + Hardhat  

### 15.3 架构优势
- 分层清晰,职责明确
- 模块化设计,易于扩展
- 配置灵活,环境隔离
- 容错机制完善
- 性能优化充分

### 15.4 下一步
1. 评审和确认方案
2. 细化开发任务
3. 搭建开发环境
4. 开始编码实现

---

**文档版本**: v1.0  
**创建日期**: 2025-11-15  
**作者**: AI Assistant  
**状态**: 待评审

